**Nueva tarea, autorizada por el autor: auditoría independiente de los resultados de la evaluación de EXP-019 (H2)** antes de declarar ninguna conclusión científica. El autor autorizó la evaluación (Notion 06, INF-2026-11-01-12) con el instrumento congelado `exp019-instrumento` = `4aa18a7` (el que aprobaste en tu tercera revisión) y la aclaración G2 (`docs/experimentos/EXP-019-aclaracion-G2.md`). El coordinador la ejecutó sin agente, en bwrap y sin red: `python3 experimentos/exp019/ejecutar.py --evaluacion --autorizacion INF-2026-11-01-12 --salida resultados/exp019/evaluacion` (lanzador en `resultados/exp019/lanzar-evaluacion.sh`).

**Material, en solo lectura, en `correccion-ciclo/`** (rama `preparacion/exp019`, commit `ca8e5d1`):
- `resultados/exp019/evaluacion/` (las 5 repeticiones, `ejecucion.jsonl`, `analisis.json`, `oraculo.json`, `entorno.json` y `base-descriptor.json`);
- `resultados/exp019/evaluacion.log`;
- `ARBOL-evaluacion.sha256`;
- `evaluacion-huellas.sha256`.
`experimentos/exp019/evaluacion/` está ahora visible en tu entorno.

**Prohibido:** modificar resultados, el instrumento, el protocolo, R1-R3 o la interpretación G2. Puedes **reproducir** en copias tuyas (en `control/tmp/`) lo que necesites, incluida una repetición de la evaluación con el instrumento congelado.

**Comprueba** (veredicto por punto: sí, no o sin conclusión):
1. **Integridad:** que todos los resultados corresponden al instrumento congelado (las 1750 líneas del JSONL con las huellas `INSTRUMENTO` `d9b495bd…`, `MANIFIESTO` `d5061e04…` y `BASE` `8db44ecb…`); que el código ejecutado es idéntico a `exp019-instrumento` (frente a `HEAD` solo difiere la aclaración G2); que no hubo modificaciones posteriores (`ARBOL-evaluacion.sha256`); y que la ejecución usó `--autorizacion INF-2026-11-01-12`.
2. **Reproducibilidad:** que las 5 repeticiones coinciden en estados, orígenes y conteos, con cualquier discrepancia señalada. **Reproduce de forma independiente** al menos una repetición completa de la evaluación, o una muestra estratificada amplia si el coste lo impide, y compárala.
3. **R1, R2 y R3:** verifica **de forma independiente**, con tu propio cálculo a partir de las celdas y sin fiarte de `analisis.json`:
   - las clasificaciones y los agregados;
   - la precedencia, incluida G2;
   - los denominadores de R1;
   - los controles K1-K8 en C y la calibración de B;
   - O2 y el confirmador sobre las raíces de C;
   - las violaciones (ninguna, según el análisis).
   Si hubiera un fallo de calibración bloqueante, **no se interpretan R2 ni R3** a partir de cálculos parciales.
4. **Robustez:** que los análisis con las 64 y con las 61 limpias se hicieron conforme al protocolo, y que las contaminadas son las preinscritas.
5. **Predicción:** compara lo observado con las predicciones preinscritas por inspección (B fortalecida: 576/116/252; 61: 105/233; histórica de la B original: 576/188/252). Si B difiere de la predicción, clasifica la causa (supuestos P1-P5, defecto del instrumento o comportamiento real) **sin cambiar ninguna decisión**.
6. **Amenazas a la validez y alcance:** ¿qué se puede y qué no se puede concluir sobre H2 con este resultado, según la ficha (dominio, base constante, PROP y R-REFUT fuera, D10 posicional `no comprobado`, D11)?

**Veredicto:** **resultados válidos** (con la conclusión preinscrita que corresponde a cada uno de R1, R2 y R3), **válidos con limitaciones** o **no válidos**, con sus motivos.

**Restricciones:** las de siempre. Copias en `control/tmp/`, borradas al terminar (hay unos 9 GB libres). Sin red, salvo la API. No toques EXP-018, E, E-v4, la enmienda 4 ni la reserva.

**Entregables** (en `control/auditoria-evaluacion/`): `informe.md` (50 líneas como máximo, con etiquetas), tu recálculo independiente y tus sondas, `reproducir.md` y `SHA256SUMS`. Vuelve a generar `control/SHA256SUMS`. Mensaje final de 12 líneas como máximo.
