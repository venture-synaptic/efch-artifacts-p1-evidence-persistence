from pathlib import Path
import json,hashlib,shutil
A=Path(__file__).resolve().parent;C=A.parent;T=C/'tmp/auditoria-evaluacion-sol';assert T.is_dir()
verified={}
for name in ['INSTRUMENTO.sha256','BASE-efch.sha256','MANIFIESTO.sha256']:
 n=0
 for line in (T/'experimentos/exp019'/name).read_text().splitlines():
  h,p=line.split(None,1);assert hashlib.sha256((T/p.strip()).read_bytes()).hexdigest()==h,(name,p);n+=1
 verified[name]=n
rec=json.loads((A/'recalculo.json').read_text());repro=json.loads((A/'reproduccion.json').read_text());assert rec['agregados']['64']['N']=={'A':576,'B':96,'C':252} and not repro['diferencias_estados_origenes_n']
assert len((A/'informe.md').read_text().splitlines())<=50
size=sum(p.stat().st_size for p in T.rglob('*') if p.is_file());shutil.rmtree(T)
(A/'limpieza.json').write_text(json.dumps({'temporal_eliminado':str(T),'existe_despues':T.exists(),'bytes_eliminados':size,'copias_sin_modificar_verificadas':verified,'resultados_originales_modificados':False,'otros_temporales_preservados':True},ensure_ascii=False,indent=1)+'\n')
for root in [A,C]:
 files=sorted(p for p in root.rglob('*') if p.is_file() and p!=root/'SHA256SUMS' and not (root==C and p.is_relative_to(C/'tmp')))
 (root/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root)}\n' for p in files))
print('Instrumento/entradas intactos; copia y almacenes propios eliminados; manifiestos regenerados.')
