"""Repetición propia, sin usar analisis.json para estados o costes."""
from pathlib import Path
import json,hashlib
import independiente as q
A=Path(__file__).resolve().parent;R=A.parent.parent/'correccion-ciclo';T=A.parent/'tmp/auditoria-evaluacion-sol';O=T/'reproduccion';SRC=R/'resultados/exp019/evaluacion';E=T/'experimentos/exp019/evaluacion'
def read(p):return json.loads(p.read_text())
order=read(E/'orden.json');q.desc=read(O/'base-descriptor.json');origdesc=read(SRC/'base-descriptor.json');nuc=list(q.NUC);assert all(q.desc[k]==origdesc[k] for k in nuc)
result={'repeticion':1,'celdas':0,'diferencias_estados_origenes_n':[],'diferencias_huella_base_fuera_clases':{k:[origdesc.get(k),q.desc.get(k)] for k in set(q.desc)|set(origdesc) if origdesc.get(k)!=q.desc.get(k)},'N':{'A':0,'B':0,'C':0},'raices_propia_comprobadas':0,'controles_resultado':{},'O2_confirmador_sin_discrepancias':0}
for item in order['repeticiones'][0]['secuencia']:
 name=item['entrada'];tab=q.tables(E/name)
 for c in item['condiciones']:
  d=O/'rep1'/name/c;f=read(d/'fase1.json');old=read(SRC/'rep1'/name/c/'fase1.json');o={z['obligacion']:z for z in f['obligaciones']};assert set(o)==set(z['obligacion'] for z in old['obligaciones'])
  def sig(x):return ({z['obligacion']:z['estado'] for z in x['obligaciones']},{z['obligacion']:z['origen'] for z in x['obligaciones']},x['medida']['contadores']['prove'])
  if sig(f)!=sig(old):result['diferencias_estados_origenes_n'].append([name,c,sig(f),sig(old)])
  for label,z in o.items():
   n=label[label.index('(')+1:-1];truth=z['clase']=='WD' or tab['S_d'][n]==tab['S_d']['f'];assert (z['estado']=='probado')==truth
  assert f['medida']['contadores']['prove']==f['medida']['contadores']['check']
  if c=='C':
   store=q.Store(d/('Q' if (d/'Q').exists() else 'almacen'))
   for z in o.values():
    if z.get('certificado'):store.cert(z['certificado'],f['S_d']);result['raices_propia_comprobadas']+=1
   for fn in ['contraste.json','fuentes.json']:assert not read(d/fn)['discrepancias']
   assert not read(d/'contraste.json')['violaciones'];assert all(v['ok'] for v in read(d/'normativo.json')['raices'].values());result['O2_confirmador_sin_discrepancias']+=1
  if name in order['transiciones']:result['N'][c]+=f['medida']['contadores']['prove']
  result['celdas']+=1
# Solo para comparar la clasificación de los controles tras verificar de nuevo datos y raíces.
a=read(O/'analisis.json');b=read(SRC/'analisis.json')
for k,v in a['controles'].items():assert v['resultado']==b['controles'][k]['resultado'];result['controles_resultado'][k]=v['resultado']
assert not result['diferencias_estados_origenes_n'] and result['N']=={'A':576,'B':96,'C':252}
logs=[json.loads(l) for l in (O/'ejecucion.jsonl').read_text().splitlines()];assert len(logs)==350;result['JSONL_lineas']=len(logs);result['decision_instrumento_reproducido']=a['decision']
(A/'reproduccion.json').write_text(json.dumps(result,ensure_ascii=False,indent=1)+'\n');out=A/'reproduccion';out.mkdir(exist_ok=True)
for n in ['ejecucion.jsonl','entorno.json','base-descriptor.json']:(out/n).write_bytes((O/n).read_bytes())
print('207 celdas reproducidas; estados/orígenes/conteos coinciden. A576 B96 C252. Raíces y O2 sin discrepancias.')
