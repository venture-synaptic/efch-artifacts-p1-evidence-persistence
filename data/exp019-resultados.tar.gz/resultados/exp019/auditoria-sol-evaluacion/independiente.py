from pathlib import Path
import re, json, hashlib, collections, csv

def read(p):
    return json.loads(p.read_text())

def sha(b):
    return hashlib.sha256(b if isinstance(b, bytes) else b.encode()).hexdigest()

def canon(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()

def objhash(x):
    return sha(canon({k: v for k, v in x.items() if k != 'id'}))
TOK = re.compile('"(?:\\\\.|[^"\\\\])*"|;[^\\n]*|[()]|[^\\s()";]+')

def parse(s):
    stack = []
    cur = []
    for t in TOK.findall(s):
        if t.startswith(';'):
            continue
        if t == '(':
            stack.append(cur)
            cur = []
        elif t == ')':
            v = cur
            cur = stack.pop()
            cur.append(v)
        else:
            cur.append(int(t) if t.isdecimal() else t)
    assert not stack and len(cur) == 1
    return cur[0]

def section(f, n):
    return next((x for x in f[2:] if isinstance(x, list) and x[0] == n))

def tables(d):
    cs = parse((d / 'candidatas.efch').read_text())[2:]
    result = {}
    for phase, fn in [('S_a', 'antes.efch'), ('S_d', 'despues.efch')]:
        fs = {f[1]: f for f in parse((d / fn).read_text())[2:]}
        w = section(fs['f'], 'output')[1][1]
        mask = (1 << w) - 1

        def val(x, env):
            if isinstance(x, int):
                return x & mask
            if isinstance(x, str):
                return env[x]
            op = x[0]
            if op == 'call':
                f = fs[x[1]]
                params = [z[1] for z in f[2:] if isinstance(z, list) and z[0] == 'input']
                args = [val(a, env) for a in x[2:]]
                return val(section(f, 'semantics')[1], dict(zip(params, args)))
            assert op in ('add', 'sub'), op
            a, b = (val(x[1], env), val(x[2], env))
            return (a + b if op == 'add' else a - b) & mask
        bodies = {n: section(f, 'semantics')[1] for n, f in fs.items()}
        bodies.update({f[1]: section(f, 'body')[1] for f in cs})
        result[phase] = {n: [val(b, {'x': x}) for x in range(mask + 1)] for n, b in bodies.items()}
    return result

class Store:

    def __init__(self, p):
        self.p = p
        self.o = {t.name: {q.stem: read(q) for q in t.glob('*.json')} for t in (p / 'objetos').iterdir() if t.is_dir()}
        self.done = set()
        self.active = set()

    def get(self, t, i):
        return self.o[t][i]

    def name(self, rv):
        return self.get('ranuras', self.get('revisiones', rv)['ranura'])['nombre']

    def cert(self, cid, sid):
        key = (cid, sid)
        if key in self.done:
            return
        assert key not in self.active, 'ciclo de premisas'
        self.active.add(key)
        c = self.get('certificados', cid)
        a = self.get('afirmaciones', c['afirmacion'])
        S = self.get('instantaneas', sid)
        assert c['id'] == cid == objhash(c) and a['id'] == objhash(a)
        typ = a['clase']
        roles = {'WD': ['objeto'], 'EQ': ['nueva', 'anterior'], 'REAL': ['candidata', 'computacion'], 'REFUT': ['candidata', 'computacion']}[typ]
        assert set(a['sujetos']) == set(roles)
        sub = {k: self.get('revisiones', v) for k, v in a['sujetos'].items()}
        for v in sub.values():
            assert objhash(v) == v['id']
            ran = self.get('ranuras', v['ranura'])
            assert objhash(ran) == ran['id']
        if typ in ('REAL', 'REFUT'):
            assert sub['candidata']['firma'] == sub['computacion']['firma']
        if typ == 'EQ':
            assert sub['nueva']['firma'] == sub['anterior']['firma'] and a['contexto'] == {'direccion': 'd->a'}
        if typ in ('WD', 'REAL'):
            assert a['contexto'] == {}
        selected = ['nueva'] if typ == 'EQ' else roles
        closure = {}
        for k in selected:
            v = sub[k]
            closure[v['ranura']] = v['id']
            closure.update(v['dependencias'])
        assert c['cierre'] == closure and all((S['revisiones'].get(k) == v for k, v in closure.items()))
        base = NUC if typ != 'REFUT' else ('efch-core', 'efch-interp', 'ejecutor', 'reglas')
        assert set(c['base']) == set(base)
        assert all((c['base'][k] == desc[k] == S['base'][k] for k in base))
        assert objhash(S) == sid
        if typ in ('REAL', 'REFUT'):
            assert c['estado'] == 'probado'
        if c['regla'] == 'directa':
            assert c['premisas'] == {} and c['procedencia'] is None
            principal = {'WD': 'objeto', 'EQ': 'nueva', 'REAL': 'candidata', 'REFUT': 'candidata'}[typ]
            assert c['objeto_verificado'] == sub[principal]['contenido']
            Sc = self.get('instantaneas', c['instantanea'])
            assert all((Sc['revisiones'].get(k) == v for k, v in closure.items())) and all((Sc['base'][k] == c['base'][k] for k in base))
        else:
            assert c['regla'] == 'R-REAL' and typ == 'REAL' and (c['instantanea'] == sid)
            p = c['premisas']
            assert set(p) == {'origen', 'wd_a', 'wd_c', 'eq'} and c['procedencia'] == p['origen']
            oc = self.get('certificados', p['origen'])
            oa = self.get('afirmaciones', oc['afirmacion'])
            assert oa['clase'] == 'REAL' and oc['estado'] == 'probado' and (oa['sujetos']['candidata'] == a['sujetos']['candidata']) and (oc['base'] == c['base'])
            self.cert(p['origen'], oc['instantanea'])
            expected = {'wd_a': ('WD', {'objeto': oa['sujetos']['computacion']}, oc['instantanea']), 'wd_c': ('WD', {'objeto': a['sujetos']['candidata']}, sid), 'eq': ('EQ', {'nueva': a['sujetos']['computacion'], 'anterior': oa['sujetos']['computacion']}, sid)}
            for k, (cl, ss, ctx) in expected.items():
                pc = self.get('certificados', p[k])
                pa = self.get('afirmaciones', pc['afirmacion'])
                assert pa['clase'] == cl and pa['sujetos'] == ss and (pc['estado'] == 'probado')
                if k == 'eq':
                    assert pc['regla'] == 'directa'
                self.cert(p[k], ctx)
        self.active.remove(key)
        self.done.add(key)

    def identity_real(self, f1, c):
        sa = self.get('instantaneas', f1['S_a'])
        sd = self.get('instantaneas', f1['S_d'])
        rid = {r['nombre']: i for i, r in self.o['ranuras'].items() if r['tipo'] == 'computacion' or (r['tipo'] == 'candidata' and r['nombre'] == c)}
        closure = {}
        for n in ['f', c]:
            v = self.get('revisiones', sa['revisiones'][rid[n]])
            closure[v['ranura']] = v['id']
            closure.update(v['dependencias'])
        return all((sd['revisiones'].get(k) == v for k, v in closure.items())) and all((sa['base'][k] == sd['base'][k] for k in NUC))
NUC=("efch-core","efch-smt","efch-interp","z3","ejecutor","reglas")
desc=None
