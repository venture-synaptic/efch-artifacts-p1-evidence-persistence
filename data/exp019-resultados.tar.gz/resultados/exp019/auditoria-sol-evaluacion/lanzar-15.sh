#!/bin/sh
# Auditoría de la corrección del ciclo de store (resume de la sesión de Sol); corrección en solo lectura en correccion/. Sol en bwrap: repo (main 79dc57c), notion y encargo en solo lectura; escribe solo en control/ y codex-home/.
# Z3/CBMC/cvc5 fijados en solo lectura. Red solo para la API. La reserva queda fuera (/home en tmpfs).
W=/home/ubuntu/efch-sol-diagnostico
CODEX_BIN=$(readlink -f "$(command -v codex || echo /home/ubuntu/.local/bin/codex)")
exec bwrap --unshare-all --share-net --die-with-parent --new-session \
  --ro-bind /usr /usr --symlink usr/bin /bin --symlink usr/lib /lib --symlink usr/lib64 /lib64 --symlink usr/sbin /sbin \
  --ro-bind /etc /etc --proc /proc --dev /dev --tmpfs /tmp --tmpfs /home --bind "$W" "$W" \
  --ro-bind "$W/repo" "$W/repo" --ro-bind /home/ubuntu/projects/efch/.vendor "$W/repo/.vendor" \
  --ro-bind "$W/notion" "$W/notion" --ro-bind "$W/encargo.md" "$W/encargo.md" --ro-bind "$W/continuar.md" "$W/continuar.md" --ro-bind "$W/auditar-store.md" "$W/auditar-store.md" --ro-bind "$W/auditar-ciclo.md" "$W/auditar-ciclo.md" --ro-bind "$W/reverificar-ciclo.md" "$W/reverificar-ciclo.md" --ro-bind "$W/auditar-register.md" "$W/auditar-register.md" --ro-bind "$W/reverificar-register.md" "$W/reverificar-register.md" --ro-bind "$W/revisar-h2.md" "$W/revisar-h2.md" --ro-bind "$W/reverificar-h2.md" "$W/reverificar-h2.md" --ro-bind "$W/reverificar-h2-3.md" "$W/reverificar-h2-3.md" --ro-bind "$W/confirmar-h2-4.md" "$W/confirmar-h2-4.md" --ro-bind "$W/auditar-instrumento.md" "$W/auditar-instrumento.md" --ro-bind "$W/reverificar-instrumento.md" "$W/reverificar-instrumento.md" --ro-bind "$W/reverificar-instrumento-3.md" "$W/reverificar-instrumento-3.md" --ro-bind "$W/auditar-evaluacion.md" "$W/auditar-evaluacion.md" --ro-bind /home/ubuntu/efch-store-ciclo "$W/correccion-ciclo" --ro-bind /home/ubuntu/projects/efch/.vendor "$W/correccion-ciclo/.vendor" --ro-bind /home/ubuntu/projects/efch/.git /home/ubuntu/projects/efch/.git --ro-bind /home/ubuntu/efch-store-d10 "$W/correccion" --ro-bind /home/ubuntu/projects/efch/.vendor "$W/correccion/.vendor" \
  --ro-bind /run/systemd/resolve /run/systemd/resolve --ro-bind "$(dirname "$CODEX_BIN")" /opt/codex \
  --chdir "$W" --clearenv --setenv HOME "$W" --setenv CODEX_HOME "$W/codex-home" \
  --setenv PATH /opt/codex:/usr/bin:/bin --setenv LANG C.UTF-8 --setenv PYTHONDONTWRITEBYTECODE 1 \
  codex exec resume -m gpt-6.1-sol --dangerously-bypass-approvals-and-sandbox \
  -o "$W/sol-final-15.md" 01a19306-9049-7490-936d-e35f4962f0f4 - < "$W/auditar-evaluacion.md"
