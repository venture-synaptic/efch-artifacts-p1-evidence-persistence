from pathlib import Path
import subprocess,hashlib,json,shutil
A=Path(__file__).resolve().parent;C=A.parent;R=C.parent/'correccion-ciclo';T=C/'tmp/auditoria-evaluacion-sol';assert not T.exists();T.mkdir(parents=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*xs):return subprocess.check_output(['git','-C',str(R),*xs],text=True)
o={'HEAD':git('rev-parse','HEAD').strip(),'instrumento_tag':git('rev-parse','exp019-instrumento^{commit}').strip(),'protocolo_tag':git('rev-parse','exp019-protocolo^{commit}').strip()}
o['cambios_fuera_resultados']=[p for p in git('diff','--name-only','exp019-instrumento','HEAD').splitlines() if not p.startswith('resultados/')]
assert o['cambios_fuera_resultados']==['docs/experimentos/EXP-019-aclaracion-G2.md']
o['manifiestos']={}
for name,cwd in [('experimentos/exp019/INSTRUMENTO.sha256',R),('experimentos/exp019/BASE-efch.sha256',R),('experimentos/exp019/MANIFIESTO.sha256',R),('ARBOL-evaluacion.sha256',R/'resultados/exp019'),('resultados/exp019/evaluacion-huellas.sha256',R)]:
 n=0
 for l in (cwd/name).read_text().splitlines():
  hv,f=l.split(None,1);f=f.strip();assert digest(cwd/f)==hv,(name,f);n+=1
 o['manifiestos'][name]=n
# Minimal transitive instrument, frozen inputs and ficha; no result tree copied.
for l in (R/'experimentos/exp019/INSTRUMENTO.sha256').read_text().splitlines():
 _,f=l.split(None,1);f=f.strip();p=T/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/f,p)
I=T/'experimentos/exp019';shutil.copy2(R/'experimentos/exp019/INSTRUMENTO.sha256',I/'INSTRUMENTO.sha256')
for fase in ['preparacion','evaluacion']:shutil.copytree(R/'experimentos/exp019'/fase,I/fase,dirs_exist_ok=True)
p=T/'docs/experimentos/EXP-019.md';p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/'docs/experimentos/EXP-019.md',p)
(A/'integridad.json').write_text(json.dumps(o,ensure_ascii=False,indent=1)+'\n');print(o)
