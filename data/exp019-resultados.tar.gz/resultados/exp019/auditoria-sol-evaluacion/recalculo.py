"""Recálculo propio desde fases/objetos/trazas. No importa el instrumento ni lee analisis.json."""
from pathlib import Path
import re,json,hashlib,collections,csv
A=Path(__file__).resolve().parent;R=A.parent/'../correccion-ciclo';E=R/'experimentos/exp019/evaluacion';OUT=R/'resultados/exp019/evaluacion'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
def objhash(x):return sha(canon({k:v for k,v in x.items() if k!='id'}))
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=1)+'\n')
# Lector y evaluación independiente, únicamente las operaciones totales del dominio congelado.
TOK=re.compile(r'"(?:\\.|[^"\\])*"|;[^\n]*|[()]|[^\s()";]+')
def parse(s):
 stack=[];cur=[]
 for t in TOK.findall(s):
  if t.startswith(';'):continue
  if t=='(':stack.append(cur);cur=[]
  elif t==')':v=cur;cur=stack.pop();cur.append(v)
  else:cur.append(int(t) if t.isdecimal() else t)
 assert not stack and len(cur)==1
 return cur[0]
def section(f,n):return next(x for x in f[2:] if isinstance(x,list) and x[0]==n)
def tables(d):
 cs=parse((d/'candidatas.efch').read_text())[2:];result={}
 for phase,fn in [('S_a','antes.efch'),('S_d','despues.efch')]:
  fs={f[1]:f for f in parse((d/fn).read_text())[2:]};w=section(fs['f'],'output')[1][1];mask=(1<<w)-1
  def val(x,env):
   if isinstance(x,int):return x&mask
   if isinstance(x,str):return env[x]
   op=x[0]
   if op=='call':
    f=fs[x[1]];params=[z[1] for z in f[2:] if isinstance(z,list) and z[0]=='input'];args=[val(a,env) for a in x[2:]];return val(section(f,'semantics')[1],dict(zip(params,args)))
   assert op in ('add','sub'),op
   a,b=val(x[1],env),val(x[2],env);return ((a+b) if op=='add' else (a-b))&mask
  bodies={n:section(f,'semantics')[1] for n,f in fs.items()};bodies.update({f[1]:section(f,'body')[1] for f in cs})
  result[phase]={n:[val(b,{'x':x}) for x in range(mask+1)] for n,b in bodies.items()}
 return result
ord=read(E/'orden.json');Ts=ord['transiciones'];Ks=ord['controles'];assert len(Ts)==64 and len(Ks)==8
meta={n:read(E/n/'meta.json') for n in Ts+Ks};TAB={n:tables(E/n) for n in Ts+Ks}
NUC=('efch-core','efch-smt','efch-interp','z3','ejecutor','reglas');desc=read(OUT/'base-descriptor.json');NAMES=['WD(f)','WD(h)','WD(q)','WD(c0)','REAL(c0)','WD(c1)','REAL(c1)','WD(c2)','REAL(c2)']
rows=[];sigs=collections.defaultdict(list);cells={};roots=checks=0;cache_checks=0;inc=[];issues=[];den_eq=den_ref=0;real_identicas=0;counts_byrep=collections.defaultdict(lambda:collections.Counter());proofs=[]
class Store:
 def __init__(self,p):
  self.p=p;self.o={t.name:{q.stem:read(q) for q in t.glob('*.json')} for t in (p/'objetos').iterdir() if t.is_dir()};self.done=set();self.active=set()
 def get(self,t,i):return self.o[t][i]
 def name(self,rv):return self.get('ranuras',self.get('revisiones',rv)['ranura'])['nombre']
 def cert(self,cid,sid):
  key=(cid,sid)
  if key in self.done:return
  assert key not in self.active,'ciclo de premisas';self.active.add(key)
  c=self.get('certificados',cid);a=self.get('afirmaciones',c['afirmacion']);S=self.get('instantaneas',sid)
  assert c['id']==cid==objhash(c) and a['id']==objhash(a)
  typ=a['clase'];roles={'WD':['objeto'],'EQ':['nueva','anterior'],'REAL':['candidata','computacion'],'REFUT':['candidata','computacion']}[typ];assert set(a['sujetos'])==set(roles)
  sub={k:self.get('revisiones',v) for k,v in a['sujetos'].items()}
  for v in sub.values():
   assert objhash(v)==v['id'];ran=self.get('ranuras',v['ranura']);assert objhash(ran)==ran['id']
  if typ in ('REAL','REFUT'):assert sub['candidata']['firma']==sub['computacion']['firma']
  if typ=='EQ':assert sub['nueva']['firma']==sub['anterior']['firma'] and a['contexto']=={'direccion':'d->a'}
  if typ in ('WD','REAL'):assert a['contexto']=={}
  selected=['nueva'] if typ=='EQ' else roles;closure={}
  for k in selected:
   v=sub[k];closure[v['ranura']]=v['id'];closure.update(v['dependencias'])
  assert c['cierre']==closure and all(S['revisiones'].get(k)==v for k,v in closure.items())
  base=NUC if typ!='REFUT' else ('efch-core','efch-interp','ejecutor','reglas');assert set(c['base'])==set(base)
  assert all(c['base'][k]==desc[k]==S['base'][k] for k in base)
  assert objhash(S)==sid
  if typ in ('REAL','REFUT'):assert c['estado']=='probado'
  if c['regla']=='directa':
   assert c['premisas']=={} and c['procedencia'] is None
   principal={'WD':'objeto','EQ':'nueva','REAL':'candidata','REFUT':'candidata'}[typ];assert c['objeto_verificado']==sub[principal]['contenido']
   Sc=self.get('instantaneas',c['instantanea']);assert all(Sc['revisiones'].get(k)==v for k,v in closure.items()) and all(Sc['base'][k]==c['base'][k] for k in base)
  else:
   assert c['regla']=='R-REAL' and typ=='REAL' and c['instantanea']==sid
   p=c['premisas'];assert set(p)=={'origen','wd_a','wd_c','eq'} and c['procedencia']==p['origen']
   oc=self.get('certificados',p['origen']);oa=self.get('afirmaciones',oc['afirmacion']);assert oa['clase']=='REAL' and oc['estado']=='probado' and oa['sujetos']['candidata']==a['sujetos']['candidata'] and oc['base']==c['base']
   self.cert(p['origen'],oc['instantanea'])
   expected={'wd_a':('WD',{'objeto':oa['sujetos']['computacion']},oc['instantanea']),'wd_c':('WD',{'objeto':a['sujetos']['candidata']},sid),'eq':('EQ',{'nueva':a['sujetos']['computacion'],'anterior':oa['sujetos']['computacion']},sid)}
   for k,(cl,ss,ctx) in expected.items():
    pc=self.get('certificados',p[k]);pa=self.get('afirmaciones',pc['afirmacion']);assert pa['clase']==cl and pa['sujetos']==ss and pc['estado']=='probado'
    if k=='eq':assert pc['regla']=='directa'
    self.cert(p[k],ctx)
  self.active.remove(key);self.done.add(key)
 def identity_real(self,f1,c):
  sa=self.get('instantaneas',f1['S_a']);sd=self.get('instantaneas',f1['S_d']);rid={r['nombre']:i for i,r in self.o['ranuras'].items() if r['tipo']=='computacion' or (r['tipo']=='candidata' and r['nombre']==c)}
  closure={}
  for n in ['f',c]:
   v=self.get('revisiones',sa['revisiones'][rid[n]]);closure[v['ranura']]=v['id'];closure.update(v['dependencias'])
  return all(sd['revisiones'].get(k)==v for k,v in closure.items()) and all(sa['base'][k]==sd['base'][k] for k in NUC)
for rep in range(1,6):
 for item in ord['repeticiones'][rep-1]['secuencia']:
  name=item['entrada'];tab=TAB[name]
  for cond in item['condiciones']:
   d=OUT/f'rep{rep}'/name/cond;f=read(d/'fase1.json');assert f['ok'] and 'obligaciones' in f,(rep,name,cond,f)
   ob={o['obligacion']:o for o in f['obligaciones']};assert set(ob)==set(NAMES)
   if cond in ('B','C'):
    f0=read(d/'fase0.json');assert f0['ok'] and not any(m['problemas'] for m in f0['monitor'])
    if cond=='C':assert f0['todas_aceptadas'] and all(z['ok'] for z in f0['aceptadas'])
    else:assert all(z['estado']=='probado' for z in f0['obligaciones'])
    co=f0.get('contadores_fase0') or f0['medida']['contadores'];assert co['prove']==co['check']
   for label,o in ob.items():
    n=label[label.index('(')+1:-1];truth=True if o['clase']=='WD' else tab['S_d'][n]==tab['S_d']['f']
    if o['estado'] not in ['probado','refutado']:inc.append([rep,name,cond,label,o['estado']])
    else:assert (o['estado']=='probado')==truth,(rep,name,cond,label)
    if o.get('testigo'):
     x=o['testigo']['x'];assert 0<=x<len(tab['S_d']['f']) and o['clase']=='REAL' and tab['S_d'][n][x]!=tab['S_d']['f'][x]
   count=f['medida']['contadores'];assert count['prove']==count['check'];assert not any(m['problemas'] for m in f['monitor'])
   tests=read(d/'testigos.json');assert tests['tablas_interp']['S_d']==tab['S_d'] and tests['tablas_interp']['S_a']=={n:tab['S_a'][n] for n in ['f','h','q']}
   for t in tests['testigos']:
    w=t.get('testigo') or t.get('eq_testigo');x=w['x']
    if 'refut' in t:assert tab['S_d'][t['cand']][x]==t['cand_v'] and tab['S_d']['f'][x]==t['f_d'] and t['cand_v']!=t['f_d']
    elif 'cand' in t:
     n=t['obligacion'][5:-1];assert tab['S_d'][n][x]==t['cand'] and tab['S_d']['f'][x]==t['f_d'] and t['cand']!=t['f_d']
    elif 'eq_testigo' in t:
     n=t['computacion'];assert tab['S_d'][n][x]==t['n_d'] and tab['S_a'][n][x]==t['n_a'] and t['n_d']!=t['n_a']
   for z in f.get('emitidas',[]):
    if z['clase']=='EQ':assert (z['estado']=='probado')==(tab['S_a'][z['sujetos']['nueva']['nombre']]==tab['S_d'][z['sujetos']['nueva']['nombre']])
   if cond=='B':
    cachefile=d/('BQ' if (d/'BQ').exists() else 'B')/'cache-B.json';cache={e['clave']:e for e in read(cachefile)['entradas'] if sha(e['texto'])==e['clave']};tr=read(d/'trazas-fase1.json');assert [t['obligacion'] for t in tr]==NAMES
    misses=0
    for t in tr:
     assert sha(t['texto'])==t['clave'];lines=t['texto'].splitlines();assert lines[0]=='QF_BV' and lines[1]==f"v0:(bv {meta[name]['ancho']})";assert json.loads(lines[-1])=={k:desc[k] for k in NUC}
     hit=t['clave'] in cache;assert hit==t['acierto'],(name,t['obligacion']);misses+=not hit
     if not hit and t['estado'] in ('probado','refutado'):cache[t['clave']]={'estado':t['estado']}
     if hit:assert cache[t['clave']]['estado']==t['estado']
     cache_checks+=1
    assert misses==count['prove'] and len(tr)-misses==count['aciertos_B']
   st=None
   if cond=='C':
    st=Store(d/('Q' if (d/'Q').exists() else 'almacen'));assert f['informe']['aceptada'] and f['informe']['instantanea_vigente']==f['S_d']==f['informe']['instantanea_nueva']
    for label,o in ob.items():
     cid=o.get('certificado')
     if cid:
      st.cert(cid,f['S_d']);cc=st.get('certificados',cid);aa=st.get('afirmaciones',cc['afirmacion']);assert aa['clase']==o['clase'];n=label[label.index('(')+1:-1];assert st.name(aa['sujetos']['objeto' if aa['clase']=='WD' else 'candidata'])==n
      expected=cc['regla'] if cc['regla']!='directa' else ('directa' if cc['instantanea']==f['S_d'] else 'conservada');assert expected==o['origen'] and cc['regla']==o['regla'] and cc['estado']==o['estado'];roots+=1
     else:
      rr=st.get('registros',o['registro']);assert rr['resultado']==o['estado'];assert sha(canon({k:v for k,v in rr.items() if k not in ('id','mediciones')}))==rr['id']
    for z in f.get('emitidas',[]):
     if z['clase']=='REFUT':st.cert(z['certificado'],f['S_d'])
    nor=read(d/'normativo.json');o2=read(d/'contraste.json');cf=read(d/'fuentes.json');assert not nor['error_paquete'] and all(v['ok'] for v in nor['raices'].values());assert not o2['violaciones'] and not o2['discrepancias'] and not cf['discrepancias']
    assert {o['certificado'] for o in ob.values() if o.get('certificado')}==set(nor['raices'])
    assert not read(d/'lector.json')['discrepancias'];checks+=1
    if name in Ts:
     for ci in ['c0','c1','c2']:
      if st.identity_real(f,ci):
       assert ob[f'REAL({ci})']['origen']!='directa' and count['verify']==0
       if rep==1:real_identicas+=1
     if rep==1:den_eq+=sum(z['clase']=='EQ' for z in f['emitidas']);den_ref+=sum(z['clase']=='REFUT' for z in f['emitidas'])
   signature={k:ob[k]['estado'] for k in NAMES},{k:ob[k]['origen'] for k in NAMES},count['prove'];sigs[name,cond].append(signature)
   cells[rep,name,cond]={'f':f,'ob':ob,'n':count['prove'],'store':st,'dir':d}
   rows.append([rep,name,cond,count['prove'],json.dumps(signature[0],sort_keys=True),json.dumps(signature[1],sort_keys=True)])
   if name in Ts:counts_byrep[rep][cond]+=count['prove']
assert all(all(s==ss[0] for s in ss) for ss in sigs.values());assert not inc
# Guardar estructuras resumidas, no importar decisiones del instrumento.
contam=sorted(n for n in Ts if meta[n]['contaminada']);assert contam==['T-w2-id-eq','T-w2-id-neq','T-w2-llamada-h']
def aggregate(names):
 N={c:sum(cells[1,n,c]['n'] for n in names) for c in 'ABC'};return {'transiciones':len(names),'N':N,'R2':'sostenida' if N['C']<N['A'] else 'refutada','rho_A':N['C']/N['A'],'R3':'inferioridad' if N['C']>N['B'] else ('igualdad' if N['C']==N['B'] else 'superioridad estricta'),'rho':N['C']/N['B'] if N['B'] else None,'N_C_menos_N_B':N['C']-N['B']}
summary={'celdas':len(rows),'repeticiones_identicas':True,'inconclusas':inc,'agregados':{'64':aggregate(Ts),'61':aggregate([n for n in Ts if n not in contam])},'contaminadas':contam,'REAL_identicas':real_identicas,'reverificaciones_directas_REAL_identicas':0,'denominadores_R1':{'obligaciones':len(Ts)*9,'EQ_emitidas':den_eq,'REFUT_emitidas':den_ref},'raices_C_comprobadas':roots,'celdas_C_O2_normativo_confirmador':checks,'consultas_B_reproducidas_por_clave':cache_checks,'por_repeticion':{str(k):dict(v) for k,v in counts_byrep.items()},'por_estrato':{}}
for s in ['ajena','eq','neq','dependencia']:
 ns=[n for n in Ts if (('dependencia' if meta[n]['cuerpo']=='llamada' else 'ajena') if meta[n]['cambio']=='h' else ('ajena' if meta[n]['cambio']=='q' else meta[n]['cambio']))==s];summary['por_estrato'][s]=aggregate(ns)
# Controles propios, incluidos activación y rechazo; no se lee controles de analisis.json.
controls=[]
def inv(c,g):
 assert c['n']==g['n'];assert [(n,c['ob'][n]['estado'],c['ob'][n]['origen'],c['ob'][n]['regla']) for n in NAMES]==[(n,g['ob'][n]['estado'],g['ob'][n]['origen'],g['ob'][n]['regla']) for n in NAMES]
for rep in range(1,6):
 for name in Ks:
  k=int(name.split('-')[0][1:]);esp=read(E/name/'esperado.json');c=cells[rep,name,'C'];f=c['f'];st=c['store'];d=c['dir'];g=cells.get((rep,esp['gemelo'],'C')) if esp['gemelo'] else None
  if k in (1,3,4):inv(c,g)
  if k==1:
   ns=read(st.p/'nombres.json');assert all(any(x['nota']=='etiqueta de control' for x in ns[n]['historial']) for n in 'hqf');assert ns['f']['historial'][-1]['nota']=='refactor equivalente (etiqueta de control)'
  if k==2:
   rid=next(i for i,r in st.o['ranuras'].items() if r['tipo']=='computacion' and r['nombre']=='f');sa=st.get('instantaneas',f['S_a']);sd=st.get('instantaneas',f['S_d']);va,vb=st.get('revisiones',sa['revisiones'][rid]),st.get('revisiones',sd['revisiones'][rid]);assert va['id']!=vb['id'] and va['contenido']==vb['contenido'];assert all(c['ob'][f'REAL({ci})']['origen'] in ('directa','R-REAL') for ci in ['c0','c1','c2'])
  if k==3:
   tr=read(d/'fase0.json')['doble_K3'];assert len(tr)==3
   for z in tr:
    aa,bb=z['antes']['obligaciones'],z['despues']['obligaciones'];assert bb[0]['obligacion']==aa[1]['obligacion'] and bb[1]['obligacion']==aa[0]['obligacion'];assert all(x['detalle']=='(CBMC)' for x in bb)
    assert all(aa[i].get(p)==bb[i].get(p) for i in range(2) for p in ['clase','herramienta','estado','contraejemplo','segundos'])
   ci=set(p for p in read(d/'disco-fase0.json') if p.startswith('objetos/'));gi=set(p for p in read(g['dir']/'disco-fase0.json') if p.startswith('objetos/'));assert ci==gi
  if k>=4:
   m=read(d/'mutacion.json');assert m['intervencion']['exacto']
   before=read(d/'disco-Q-antes-fase1.json');pp=d/'P';ps={str(p.relative_to(pp)):sha(p.read_bytes()) for p in pp.rglob('*') if p.is_file()};actual={'cambiados':sorted(p for p in ps if p in before and ps[p]!=before[p]),'nuevos':sorted(p for p in before if p not in ps),'borrados':sorted(p for p in ps if p not in before)};assert actual=={k:sorted(v) for k,v in m['previsto'].items()}
  if k==4:
   pstore=Store(d/'P');cs=[cc for cc in pstore.o['certificados'].values() if cc['regla']=='directa' and cc['estado']=='probado' and pstore.get('afirmaciones',cc['afirmacion'])['clase']=='REAL' and pstore.name(pstore.get('afirmaciones',cc['afirmacion'])['sujetos']['candidata'])=='c0'];assert len(cs)==2 and len({cc['instantanea'] for cc in cs})==2
   for cc in cs:st.cert(cc['id'],f['S_d'])
   cp,cq=read(d/'P/costes.json'),read(d/'Q/costes.json')
   mx,mn=max(v['orden'] for v in cp.values()),min(v['orden'] for v in cp.values())
   for cid,v in cp.items():
    assert cq[cid]['orden']==mx+mn-v['orden']
    if isinstance(v.get('segundos'),(int,float)):assert cq[cid]['segundos']==v['segundos']*1000
   a,b=cs[0]['id'],cs[1]['id'];assert (cp[a]['orden']<cp[b]['orden'])!=(cq[a]['orden']<cq[b]['orden']);assert c['ob']['REAL(c0)']['certificado'] in {a,b}
  if k>=5:
   pstore=Store(d/'P');af0=pstore.get('afirmaciones',m['A0']);r0=pstore.get('certificados',m['R0']);want_r=dict(r0)
   if k in (5,6):
    want_a={z:v for z,v in af0.items() if z!='clase'} if k==5 else {**af0,'clase':'WD'};want_a['id']=objhash(want_a);assert st.get('afirmaciones',m["A0'"])==want_a;want_r['afirmacion']=want_a['id']
   else:
    want_r['base']=dict(r0['base'])
    if k==7:want_r['base'].pop('z3')
    else:want_r['base']['z3']='4.8.0:otra'
   want_r['id']=objhash(want_r);assert st.get('certificados',m["R0'"])==want_r
   banned={v for v in [m.get("A0'"),m.get("R0'")] if v};origin=g['store'].get('certificados',g['ob']['REAL(c0)']['certificado']);assert origin['regla']=='R-REAL' and origin['procedencia']==m['R0'];assert not m['localizacion']['referencias_ajenas']
   for cc in st.o['certificados'].values():
    if cc['id'] in banned:continue
    assert not (set(cc['premisas'].values())&banned) and cc['procedencia'] not in banned and cc['afirmacion'] not in banned
   codes=set(esp['codigos_admitidos']);diag=any(x[1] in banned and x[2] in codes for x in f['descartados']);rej=(f['informe'].get('rechazos_transferencia') or {}).get('c0') or []
   if not diag:
    possible=[cc for cc in st.o['certificados'].values() if f"objetos/certificados/{cc['id']}.json" in before and st.get('afirmaciones',cc['afirmacion']).get('clase')=='REAL' and st.name(st.get('afirmaciones',cc['afirmacion'])['sujetos']['candidata'])=='c0'];assert len(possible)==1 and possible[0]['id']==m["R0'"];diag=any(x['codigo'] in codes for x in rej)
   assert diag and c['ob']['REAL(c0)']['origen']=='directa' and c['ob']['REAL(c0)']['estado']=='probado';assert all(c['ob'][f'REAL({x})']['origen']=='R-REAL' for x in ['c1','c2'])
  controls.append({'rep':rep,'entrada':name,'condicion':'C','resultado':'superado'})
  if esp['calibracion_B']:
   b=cells[rep,name,'B'];tr=read(b['dir']/'trazas-fase1.json');bg=cells.get((rep,esp['gemelo'],'B')) if esp['gemelo'] else None
   if k==2:assert b['n']==0 and all(t['acierto'] for t in tr)
   elif k in (1,4):
    tg=read(bg['dir']/'trazas-fase1.json');assert [(t['obligacion'],t['clave'],t['acierto'],t['estado']) for t in tr]==[(t['obligacion'],t['clave'],t['acierto'],t['estado']) for t in tg] and b['n']==bg['n']
    if k==1:assert all(t['etiqueta'].startswith('(etiqueta de control) ') for t in tr)
    else:
     initial=read(b['dir']/'B/cache-B.json')['entradas'];changed=read(b['dir']/'BQ/cache-B.json')['entradas'];assert changed==list(reversed(initial))
   else:
    mu=read(b['dir']/'mutacion-B.json')
    initial=read(b['dir']/'B/cache-B.json')['entradas'];changed=read(b['dir']/'BQ/cache-B.json')['entradas'];idx=next(i for i,v in enumerate(initial) if v['clave']==mu['E0']);lines=initial[idx]['texto'].split('\n')
    if k==5:lines=[lines[0]]+lines[2:]
    elif k==6:lines[1]=lines[1].replace(f"(bv {meta[name]['ancho']})",f"(bv {meta[name]['ancho']+1})")
    elif k==7:lines=lines[:-1]
    else:
     altered=json.loads(lines[-1]);altered['z3']='4.8.0:otra';lines[-1]=canon(altered).decode()
    text='\n'.join(lines);expected=[dict(v) for v in initial];expected[idx]={**expected[idx],'texto':text,'clave':mu['E0'] if k==5 else sha(text)};assert changed==expected
    tg=read(bg['dir']/'trazas-fase1.json');assert mu['diff']==['cache-B.json'];E0=mu['E0'];affected=[i for i,t in enumerate(tg) if t['acierto'] and t['clave']==E0];assert affected and b['n']==bg['n']+len(affected)
    for i,t in enumerate(tr):
     if i in affected:assert not t['acierto'] and t['clave']==tg[i]['clave'] and t['estado']==tg[i]['estado']
     else:assert (t['obligacion'],t['clave'],t['acierto'],t['estado'])==(tg[i]['obligacion'],tg[i]['clave'],tg[i]['acierto'],tg[i]['estado'])
    if k==5:assert any(x['clave']==E0 and x['motivo']=='clave ≠ sha256(texto)' for x in b['f']['descartadas'])
   controls.append({'rep':rep,'entrada':name,'condicion':'B','resultado':'superado'})
summary['REAL_por_origen_estado']=dict(collections.Counter(cells[1,n,'C']['ob'][f'REAL({ci})']['origen']+':'+cells[1,n,'C']['ob'][f'REAL({ci})']['estado'] for n in Ts for ci in ['c0','c1','c2']));summary['controles']=controls;summary['violaciones_detectadas']=[];summary['calibracion_bloqueante_detectada']=[];summary['precedencia']=5;summary['R1']='sostenida en este dominio y esta base';summary['R1_controles_C_superados']=8
# JSONL completo y tres huellas oficiales, cotejado con orden/fases, sin usar el resumen del instrumento.
logs=[json.loads(l) for l in (OUT/'ejecucion.jsonl').read_text().splitlines()];expected={(r,n,c,phase) for r,n,c in cells for phase in ([0,1] if c in 'BC' else [1])};observed=[(x['repeticion'],x['entrada'],x['condicion'],x['fase']) for x in logs];expected_sequence=[(block['repeticion'],item['entrada'],c,phase) for block in ord['repeticiones'] for item in block['secuencia'] for c in item['condiciones'] for phase in ([0,1] if c in 'BC' else [1])];assert observed==expected_sequence
assert len(logs)==1750 and set(observed)==expected and len(observed)==len(set(observed)) and all(x['rc']==0 for x in logs)
hashes={n:sha((R/'experimentos/exp019'/n).read_bytes()) for n in ['INSTRUMENTO.sha256','MANIFIESTO.sha256','BASE-efch.sha256']};assert all(x['huellas']==hashes for x in logs);summary['JSONL']={'lineas':len(logs),'coincide_orden_fases':True,'huellas':hashes,'todos_rc0':True}
summary['autorizacion_en_lanzador']='--autorizacion INF-2026-11-01-12' in (R/'resultados/exp019/lanzar-evaluacion.sh').read_text();assert summary['autorizacion_en_lanzador']
with (A/'celdas.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['repeticion','entrada','condicion','llamadas','estados','origenes']);w.writerows(rows)
save(A/'semantica_independiente.json',TAB);save(A/'recalculo.json',summary);print(json.dumps({k:v for k,v in summary.items() if k!='controles'},ensure_ascii=False,indent=1))
