Auditoría de ca8e5d19, instrumento exp019-instrumento^{commit}=4aa18a74, protocolo exp019-protocolo^{commit}=d94471af. Evaluación autorizada por INF-2026-11-01-12. Solo escribir en control/; no red ni cambios a resultados/instrumento/protocolo. Los tags son anotados: se usan commits pelados, no hashes del objeto tag.

1. Integridad y copia mínima. preparar.py verifica INSTRUMENTO, BASE, MANIFIESTO, ARBOL-evaluacion (desde resultados/exp019/) y evaluacion-huellas; compara Git con el instrumento congelado. Copia únicamente las dependencias de INSTRUMENTO, los dos conjuntos de entradas necesarios para verificar MANIFIESTO y la ficha. No copia resultados originales.

```bash
ulimit -v 8000000
timeout 240 python3 control/auditoria-evaluacion/preparar.py > control/auditoria-evaluacion/integridad.log 2>&1
AUDIT_ROOT="$PWD/control/tmp/auditoria-evaluacion-sol"
PYTHONDONTWRITEBYTECODE=1 timeout 1800 python3 "$AUDIT_ROOT/experimentos/exp019/ejecutar.py" --evaluacion --autorizacion INF-2026-11-01-12 --reps 1 --salida control/tmp/auditoria-evaluacion-sol/reproduccion > control/auditoria-evaluacion/reproduccion.log 2>&1
```

La repetición completa genera 207 celdas y 350 fases. El lanzador aplica a sus subprocesos 4194304 KiB y timeout de 900/600 s por fase; Z3 120 s por llamada. El proceso exterior hereda ulimit 8000000 KiB y timeout 1800. No se invocan CBMC, synth, LLM ni otros experimentos. Mi copia carece del CBMC auxiliar del coordinador; las seis huellas normativas de las clases medidas son idénticas.

2. Recálculo independiente original. recalculo.py NO importa el instrumento ni lee analisis.json. Lee las cinco repeticiones de fase0/fase1, objetos, trazas y dictámenes O2/normativo/fuentes/testigos. Su lector/evaluador propio enumera todos los valores de bv1–4, replay de claves y estados B, prueba condiciones contractuales de raíces y premisas en cada contexto, activación/mutación/resultado de K1–K8 y calibración B. Comprueba el orden exacto de las 1750 líneas y sus tres huellas. Genera recalculo.json, celdas.csv y semantica_independiente.json. Un assert fallido detiene el recálculo: no se publican agregados parciales como válidos.

```bash
timeout 600 python3 control/auditoria-evaluacion/recalculo.py > control/auditoria-evaluacion/recalculo.log 2>&1
```

Se conservó recalculo-intento1.log: el primer lector suponía que tablas_interp.S_a incluía candidatas; el formato real incluye solo h/q/f en S_a y también candidatas en S_d. Se corrigió mi expectativa de formato, no datos ni decisiones, y se validaron todos los campos presentes contra tablas propias. Las comprobaciones posteriores añadieron validación exacta de mutaciones, costes, fase0, cero reverificaciones REAL idénticas y orden del JSONL; ninguna alteró los resultados originales.

3. Comparar la repetición independiente. independiente.py contiene solo mis funciones puras/Store extraídas del recálculo, sin su bucle original. comparar.py usa esas funciones para comprobar otra vez las 600 raíces propias y semántica; compara cada salida nueva con la original en estados, orígenes y conteos. Solo después compara las etiquetas de los 15 controles con el resumen del instrumento, cuya clasificación original ya se calculó independientemente en el paso 2.

```bash
PYTHONDONTWRITEBYTECODE=1 timeout 180 python3 control/auditoria-evaluacion/comparar.py > control/auditoria-evaluacion/comparar.log 2>&1
```

reproduccion.json conserva el contraste completo y la diferencia auxiliar cbmc. reproduccion/ conserva JSONL, entorno, descriptor y celdas.json (inventario de estados/orígenes/conteos de las 207 celdas). Para regenerar celdas.json basta leer cada rep1/entrada/condicion/fase1.json siguiendo orden.json, tomando obligaciones y medida.contadores.prove; esos mismos campos se comparan en comparar.py.

4. Causa de la discrepancia predictiva. Construcción de AST/claves con Z3 y CacheB congeladas; no se llama a Solver ni simplify, ni se modifica N. Se inspeccionan además los 20 aciertos no previstos en las trazas originales.

```bash
PYTHONDONTWRITEBYTECODE=1 timeout 60 python3 control/auditoria-evaluacion/sondas/prediccion.py > control/auditoria-evaluacion/sondas/prediccion.log 2>&1
```

prediccion.json conserva árboles distintos, textos/claves iguales y cada acierto. Es un error de inferencia en la derivación de P1, no una adaptación del experimento: los dos AST conservan estructura distinta, pero sexpr no es inyectivo. Predicciones, mezcla, contaminadas, R1–R3 y G2 quedan intactos.

5. Cerrar después del informe. cerrar.py verifica que las 209 dependencias copiadas siguen idénticas a INSTRUMENTO y que los inputs/ficha siguen idénticos a MANIFIESTO, elimina exclusivamente control/tmp/auditoria-evaluacion-sol/ (incluidos almacenes de la repetición propia) y registra limpieza.json. Conserva datos derivados de esta auditoría y no borra temporales anteriores; regenera los manifiestos local/global excluyendo control/tmp/.

```bash
timeout 120 python3 control/auditoria-evaluacion/cerrar.py
(cd control/auditoria-evaluacion && sha256sum -c SHA256SUMS)
(cd control && sha256sum -c SHA256SUMS)
```

La copia propia fue eliminada al terminar. No se ejecutó la suite general ni EXP-018, E/E-v4, enmienda 4 o reserva. El lanzador bwrap del coordinador se leyó como evidencia de autorización/aislamiento declarado, no se modificó ni se reejecutó sobre resultados originales.
