**Resultados válidos en el dominio preinscrito.**

- **R1:** sostenida, sin violaciones observadas.
- **R2:** sostenida: 252 frente a 576 llamadas.
- **R3:** superioridad refutada: C necesita 252 llamadas frente a 96 de B.

Los 20 aciertos adicionales de B se explican por `sexpr()` de Z3, no por un defecto del instrumento. La repetición completa coincide.

[Informe y evidencias](/home/ubuntu/efch-sol-diagnostico/control/auditoria-evaluacion/informe.md). Manifiestos verificados y copias eliminadas.