"""P1: construir AST y claves, sin simplify, Solver ni modificación de código."""
from pathlib import Path
import sys,json
A=Path(__file__).resolve().parents[1];T=A.parent/'tmp/auditoria-evaluacion-sol';I=T/'experimentos/exp019';sys.path[:0]=[str(T),str(I)]
from efch._z3 import z3
import arnes
R=A.parent.parent/'correccion-ciclo';O=R/'resultados/exp019/evaluacion/rep1';desc=json.loads((O.parent/'base-descriptor.json').read_text());cache=arnes.CacheB(desc)
t=z3.BoolVal(True);left=z3.And(z3.And(t,t),t);right=z3.And(t,z3.And(t,t));x=z3.BitVec('x',3)
a=cache.normalizar(left,[],[('x',('bv',3),x)]);b=cache.normalizar(right,[],[('x',('bv',3),x)])
out={'z3':z3.get_version_string(),'AST_iguales':left.eq(right),'sexpr_izquierda':left.sexpr(),'sexpr_derecha':right.sexpr(),'num_args':[left.num_args(),right.num_args()],'args_hijos':[[c.num_args() for c in left.children()],[c.num_args() for c in right.children()]],'claves_N_iguales':a[0]==b[0],'sin_simplify_ni_solver':True,'casos':[]}
assert left.sexpr()==right.sexpr() and a[0]==b[0]
for w in range(1,5):
 for body in ['inc','llamada']:
  for change in ['eq','neq']:
   name=f'T-w{w}-{body}-{change}';d=O/name/'B';ts=json.loads((d/'trazas-fase1.json').read_text());hit=next(v for v in ts if v['obligacion']=='WD(f)');assert hit['acierto'] and hit['origen']['fase']==0 and hit['origen']['obligacion']=='WD(c1)';out['casos'].append({'id':name,'acierto_no_previsto':hit,'llamadas_observadas':sum(not t['acierto'] for t in ts),'llamadas_predichas':4})
 name=f'T-w{w}-llamada-h';d=O/name/'B';ts=json.loads((d/'trazas-fase1.json').read_text());hit=next(v for v in ts if v['obligacion']=='WD(c1)');assert hit['acierto'] and hit['origen']['fase']==0 and hit['origen']['obligacion']=='WD(c2)';out['casos'].append({'id':name,'acierto_no_previsto':hit,'llamadas_observadas':sum(not t['acierto'] for t in ts),'llamadas_predichas':5})
assert len(out['casos'])==20
out['diferencia_total']={'predicho':116,'observado':96,'aciertos_adicionales':20,'limpias_predicho':105,'limpias_observado':86,'aciertos_adicionales_limpias':19};out['clasificacion']='Error en la derivación asociada a P1: se supuso que AST distintos tendrían textos distintos, recíproca no garantizada por P1. Los AST siguen distintos; sexpr imprime And asociativos aplanados sin que N añada simplify o normalización. Comportamiento real de la versión fijada de Z3, no debilitamiento de B ni defecto observado del instrumento; P2-P5 no contradichos en estos casos.'
(A/'sondas/prediccion.json').write_text(json.dumps(out,ensure_ascii=False,indent=1)+'\n');print('P1: AST distintos, sexpr iguales; 16+4 aciertos adicionales explican B116→96, y 105→86 en limpias.')
