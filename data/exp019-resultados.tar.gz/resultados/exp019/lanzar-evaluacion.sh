#!/bin/sh
# Coordinador: evaluación de EXP-019 (autorización INF-2026-11-01-12) con el instrumento exp019-instrumento; sin agente ni red.
D=/home/ubuntu/efch-store-ciclo
X=/home/ubuntu/efch-store-ciclo/experimentos/exp019
exec bwrap --unshare-all --die-with-parent --new-session \
  --ro-bind /usr /usr --symlink usr/bin /bin --symlink usr/lib /lib --symlink usr/lib64 /lib64 --symlink usr/sbin /sbin \
  --ro-bind /etc /etc --proc /proc --dev /dev --tmpfs /tmp --tmpfs /home --ro-bind "$D" "$D" \
  --bind "$D/resultados/exp019" "$D/resultados/exp019" \
  --ro-bind /home/ubuntu/projects/efch/.vendor/cbmc-6.11.0 "$D/.vendor/cbmc-6.11.0" \
  --chdir "$D" --clearenv --setenv HOME /tmp --setenv PATH /usr/bin:/bin --setenv LANG C.UTF-8 --setenv PYTHONDONTWRITEBYTECODE 1 \
  /bin/sh -c "ulimit -v 8000000; python3 experimentos/exp019/ejecutar.py --evaluacion --autorizacion INF-2026-11-01-12 --salida resultados/exp019/evaluacion > resultados/exp019/evaluacion.log 2>&1; echo rc=\$? >> resultados/exp019/evaluacion.log"
